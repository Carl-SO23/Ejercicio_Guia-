﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form2
            // 
            this.ClientSize = new System.Drawing.Size(200, 100);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
        }
    }
}


