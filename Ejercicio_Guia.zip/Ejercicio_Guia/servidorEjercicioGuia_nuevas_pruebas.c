#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <pthread.h>
#include <ctype.h>

int contador;

//Estructura necesaria para acceso excluyente
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int i;
int sockets[100];

void* AtenderCliente(void* socket)
{
	int sock_conn;
	int* s;
	s = (int*)socket;
	sock_conn = *s;

	char buffer[80];
	int n;

	while (1)
	{
		n = recv(sock_conn, buffer, 80, 0);
		if (n <= 0) break;

		buffer[n] = '\0';

		// Bloqueo para modificar el contador
		pthread_mutex_lock(&mutex);
		contador++;
		pthread_mutex_unlock(&mutex);

		// Interpretamos la petici�n
		// Formato esperado: "codigo/nombre"
		int codigo;
		char nombre[70];
		sscanf(buffer, "%d/%s", &codigo, nombre);

		char respuesta[120];
		if (codigo == 1) // pal�ndromo
		{
			int len = strlen(nombre);
			int esPal = 1;
			for (int j = 0; j < len / 2 && esPal; j++)
			{
				if (tolower(nombre[j]) != tolower(nombre[len - 1 - j]))
					esPal = 0;
			}
			if (esPal)
				sprintf(respuesta, "El nombre %s S� es pal�ndromo", nombre);
			else
				sprintf(respuesta, "El nombre %s NO es pal�ndromo", nombre);
		}
		else if (codigo == 2) // may�sculas
		{
			for (int j = 0; nombre[j]; j++)
				nombre[j] = toupper(nombre[j]);
			sprintf(respuesta, "En may�sculas: %s", nombre);
		}
		else
		{
			sprintf(respuesta, "C�digo no reconocido");
		}

		send(sock_conn, respuesta, strlen(respuesta), 0);
	}

	close(sock_conn);
	return NULL;
}

int main(int argc, char* argv[])
{
	int sock_listen;
	struct sockaddr_in serv_adr;
	int sock_conn;
	socklen_t longc;

	sock_listen = socket(AF_INET, SOCK_STREAM, 0);
	if (sock_listen < 0)
	{
		printf("Error al crear socket");
		return -1;
	}

	bzero(&serv_adr, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(50000);
	if (bind(sock_listen, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) < 0)
		printf("Error al bind");

	if (listen(sock_listen, 3) < 0)
		printf("Error en el Listen");

	contador = 0;
	i = 0;

	while (1)
	{
		longc = sizeof(struct sockaddr_in);
		sock_conn = accept(sock_listen, (struct sockaddr*)NULL, &longc);
		if (sock_conn < 0)
		{
			printf("Error en accept\n");
			continue;
		}

		sockets[i] = sock_conn;
		pthread_t thread;
		pthread_create(&thread, NULL, AtenderCliente, &sockets[i]);
		i = i + 1;
	}

	close(sock_listen);
	return 0;
}

